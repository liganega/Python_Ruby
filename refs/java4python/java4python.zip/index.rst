.. Java for Python Programmers documentation master file, created by
   sphinx-quickstart on Sun Nov  6 13:25:21 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Java for Python Programmers
***************************

There is a :ref:`search` and :ref:`genindex`.

A `PDF version <../java4python.pdf>`_ and  `source code <../java4python.zip>`_ are available.

Contents:

.. toctree::
   :maxdepth: 2

   java4python.preface.rst
   java4python.start.rst
   java4python.basics.rst
   java4python.datatypes.rst
   java4python.classes.rst
