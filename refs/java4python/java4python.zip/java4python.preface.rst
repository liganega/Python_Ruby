Preface
=======

Preface to the third edition
-----------------------------

Welcome to *Java for Python Programmers*.  This is a quick
introduction to `Java <http://java.sun.com>`_ for programmers that
already know another language, preferably `Python
<http://www.python.org>`_.

We will begin by looking at a very simple Java program, just to see
what the language looks like and how we get a program to run.  Next,
we will look at the basic syntax of Java, and relate it to python. We
will then spend some time looking at inductively defined functions and
array.  Finally, we will look at how to define our own classes in
Java.

This edition of the text is adapted to the data structures classes
taught at DePaul.  As our primary text, we use `Algorithms 4e
<http://algs4.cs.princeton.edu/>`_.  The main changes are to the
section on classes.  I've also added a new section on inductive
programming over arrays using iteration and recursion.

James Riely `jriely@cs.depaul.edu <mailto://jriely@cs.depaul.edu>`_ December,
2013

    |image|
    This work is licensed under a Creative Commons Attribution 3.0
    United States License. See http://creativecommons.org

Preface to the second edition
-----------------------------

Welcome to *Java for Python Programmers*. This short ebook is an ongoing
project to help Computer Science students who have had one or two
semesters of Python learn the Java programming language. If you are not
a part of that audience you may still find this a useful way to learn
about Java. This book is written using the build on what you know
philosophy. In order to help you learn Java I will start with a Python
example and then implement the example in Java. Along the way we will
examine the strengths, weaknesses and differences between those two
languages.

This book does not attempt to replace the many good Java reference books
that are available, in fact I use this in my course along with
Horstman’s *Core Java* volumes. Please feel free to use this book for
yourself, or if it fits a class you are teaching you are welcome to use
this as a resource for your own class.

I have published this article using a Creative Commons license to
encourage you to use it, change it, and modify it for your own purposes.
I would appreciate knowing what you think if you do use this book, and I
would love to see any modifications or additions you make.

Brad Miller `bmiller@luther.edu <mailto://bmiller@luther.edu>`_ January,
2008

    |image|
    This work is licensed under a Creative Commons Attribution 3.0
    United States License. See http://creativecommons.org


Shameless Plug 
~~~~~~~~~~~~~~

At Luther college we use Python for CS1 and CS2.
When we decided to make the switch to introducing CS with Python we
wanted to provide our students with two semesters of Python. The reason
is that after one semester students are just getting comfortable with
the language and it does not make sense to push them into a brand new
language just as they are getting some comfort. The second reason is
that Python really is a great language for teaching data structures. The
language makes the algorithms evident by clearing away all of the
syntactic clutter. So we (David Ranum and I) wrote a CS2 book called
`Problem Solving with Algorithms and Data Structures using
Python <http://www.amazon.com/Problem-Solving-Algorithms-Structures-Python/dp/1590280539>`_.
After we finished the CS2 book we decided to write our own CS1 book as
well. This book will be available for Fall 2008 classes from Jones and
Bartlett publishers. The tentative title is *Python in Context*. Please
feel free to contact me for more information.

.. |image| IMAGE:: media/somerights20.png

